import pandas
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.pipeline import make_pipeline
import pickle
import nltk
from nltk.corpus import stopwords

# В ручную разделить на тестовую и обучающую, чтобы учесть качественный состав. 
# Рассчитать accuracy по тестовой части 80 на 20. 
# Разобраться с векторизаций, разобраться с логистической регрессией, если точность больше 70% то можно отсылать.
# Разобраться с методами обработки естественного языка (лемматизация, стоп слова...). 

nltk.download('stopwords')
russian_stop_words = stopwords.words('russian')

path = 'C:/Users/redmi/Desktop/Aisd_lab1/L.csv'
l_data = pandas.read_csv(path, delimiter=';', encoding='cp1251')

l_data = l_data.dropna(subset=['Group', 'Cat'])

l_data['Group_Cat'] = l_data['Group'] + ' - ' + l_data['Cat']

X = l_data['Desc']  
y = l_data['Group_Cat']  

split_index = int(0.8 * len(l_data))
X_train = X[:split_index]
y_train = y[:split_index]
X_test = X[split_index:]
y_test = y[split_index:]

model = make_pipeline(
    TfidfVectorizer(stop_words=russian_stop_words), 
    LogisticRegression(max_iter=1000))

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print(f"точность модели : {accuracy * 100:.2f}%") #на тестовой выборке

model_path = 'C:/Users/redmi/Desktop/Aisd_lab1/model/my_model.pkl'
with open(model_path, 'wb') as f:
    pickle.dump(model, f)

print("модель обучена в model/my_model.pkl")


