
import numpy as np
import matplotlib.pyplot as plt

def logistic_function(x):
    return 1 / (1 + np.exp(-x))

x_values = np.linspace(-10, 10, 100)  
y_values = logistic_function(x_values)

plt.figure(figsize=(8, 6))
plt.plot(x_values, y_values, label='Логистическая функция', color='blue')
plt.title('Логистическая функция в контексте классификации заявок')
plt.xlabel('Значение x (входной сигнал)')
plt.ylabel('Вероятность')
plt.axhline(0.5, color='gray', linestyle='--', label='Порог вероятности (0.5)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

