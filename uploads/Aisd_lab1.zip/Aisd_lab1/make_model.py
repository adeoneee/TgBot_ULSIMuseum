import pandas as pd
import pickle
data_path = 'C:/Users/redmi/Desktop/Aisd_lab1/C.csv'
c_data = pd.read_csv(data_path, delimiter=';', encoding='cp1251')

model_path = 'C:/Users/redmi/Desktop/Aisd_lab1/model/my_model.pkl'
with open(model_path, 'rb') as f:
    model = pickle.load(f)

c_data['Group_Cat'] = model.predict(c_data['Desc'])

c_data['Group'] = c_data['Group_Cat'].apply(lambda x: x.split(' - ')[0])
c_data['Cat'] = c_data['Group_Cat'].apply(lambda x: x.split(' - ')[1])

result_path = 'C:/Users/redmi/Desktop/Aisd_lab1/result/A.csv'
c_data[['Number', 'Date', 'UID', 'Desc', 'Group', 'Cat']].to_csv(result_path, sep=';', index=False, encoding='cp1251')


print(f"Классификация завершена. Результаты сохранены в {result_path}")
